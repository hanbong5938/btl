package com.btl.findjob.model;

import java.util.Date;

import lombok.Data;

@Data
public class KakaoPayApprovalVO {
    
    //response
    private String aid, tid, cid, sid;//cid 가맹점 필수 코드, tid 결제 고유번호 unique값
    private String partner_order_id, partner_user_id, payment_method_type;//가맹점주문번호, 가맨정회원id, 페이 방
    private AmountVO amount;
    private CardVO card_info;//카드정보
    private String item_name, item_code, payload;//상품이름, 상품코드, 해당 request와 저장해서 매핑하고 싶은 값?
    private Integer quantity, tax_free_amount, vat_amount;//수랑, 비과세금액, 부과세금액   로 수정, vat_amount가 null 받아와서 total_amount 수정
    private Date created_at, approved_at;//결제 준비요청시간, 결제 승인시각

    private int total;//총점 정보 불러오기 위해서 추가
    
    
}
 
