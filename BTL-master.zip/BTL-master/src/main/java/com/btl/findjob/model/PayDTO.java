package com.btl.findjob.model;

import java.util.Date;

public class PayDTO {
	int pay_id;
	int user_id;
	int pay_price; //결제금액
	Date pay_date; //결제 날짜
	
}
