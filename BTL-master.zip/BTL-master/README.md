# BTL

등급에 따라 사람인의 채용 정보와 회사에 대한 평가 등에 대해 보여주는 사이트

[포트폴리오 문서](findjob-.pdf)

[시연 영상](https://www.youtube.com/watch?v=efxjcBw0Xmk)
